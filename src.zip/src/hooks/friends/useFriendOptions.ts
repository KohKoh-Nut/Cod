import { useState, useCallback } from "react";
import { supabase } from "@/utils/supabase-client";

export interface FriendOption {
    id: string;
    username: string;
}

// Lightweight friends list for pickers (e.g. the share-with-friends
// multiselect) -- unlike useFriends, this only fetches the accepted
// friends list, not pending requests or search state.
export function useFriendOptions() {
    const [friends, setFriends] = useState<FriendOption[]>([]);
    const [loading, setLoading] = useState(false);

    const loadFriends = useCallback(async (userId: string) => {
        setLoading(true);
        const { data, error } = await supabase
            .from("friends")
            .select(`friend:profiles!friends_friend_id_fkey (id, username)`)
            .eq("user_id", userId);

        if (error) {
            console.error("Error fetching friends:", error.message);
            setFriends([]);
        } else {
            setFriends(
                (data ?? []).map((d: any) => ({
                    id: d.friend.id,
                    username: d.friend.username,
                })),
            );
        }
        setLoading(false);
    }, []);

    return { friends, loading, loadFriends };
}
