import { useState, useEffect } from "react";
import { supabase } from "@/utils/supabase-client";
import { Share } from "@/types/share";

export type ProfileVisibility = "public" | "friends" | "private";

export interface Profile {
    id: string;
    username: string;
    email: string;
    visibility: ProfileVisibility;
}

export type ViewerRelation = "owner" | "friend" | "stranger";

const SHARE_FIELDS =
    "id, code, language, created_at, user_id, visibility, history";

// Shares sent from `senderId` to `recipientId`
async function fetchSharesBetween(
    senderId: string,
    recipientId: string,
): Promise<Share[]> {
    const { data, error } = await supabase
        .from("share_recipients")
        .select(`share:shares!share_recipients_share_id_fkey (${SHARE_FIELDS})`)
        .eq("sender_id", senderId)
        .eq("recipient_id", recipientId);

    if (error) {
        console.error("Error fetching shares between users:", error.message);
        return [];
    }
    return (data ?? []).map((row: any) => row.share as Share);
}

export function useProfile(username: string, currentUserId: string) {
    const [profile, setProfile] = useState<Profile | null>(null);
    const [shares, setShares] = useState<Share[]>([]);
    const [sharedWithRecipient, setSharedWithRecipient] = useState<Share[]>([]);
    const [sharedWithMe, setSharedWithMe] = useState<Share[]>([]);
    const [relation, setRelation] = useState<ViewerRelation>("stranger");
    const [canView, setCanView] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        if (!username || !currentUserId) return;
        fetchProfile();
    }, [username, currentUserId]);

    const fetchShares = async (userId: string) => {
        const { data, error } = await supabase
            .from("shares")
            .select(SHARE_FIELDS)
            .eq("user_id", userId)
            .order("created_at", { ascending: false });
        if (error) {
            console.error("Error fetching shares:", error.message);
            return;
        }
        setShares((data as Share[]) ?? []);
    };

    const fetchProfile = async () => {
        setIsLoading(true);
        setError("");

        const { data: profileData, error: profileError } = await supabase
            .from("profiles")
            .select("id, username, email, visibility")
            .eq("username", username)
            .single();

        if (profileError || !profileData) {
            setError("User not found.");
            setIsLoading(false);
            return;
        }

        const profile = profileData as Profile;
        setProfile(profile);

        if (profile.id === currentUserId) {
            setRelation("owner");
            setCanView(true);
            await fetchShares(profile.id);
            setIsLoading(false);
            return;
        }

        const { data: friendData } = await supabase
            .from("friends")
            .select("id")
            .eq("user_id", currentUserId)
            .eq("friend_id", profile.id)
            .maybeSingle();

        const isFriend = !!friendData;
        setRelation(isFriend ? "friend" : "stranger");

        const allowed =
            profile.visibility === "public" ||
            (profile.visibility === "friends" && isFriend);
        setCanView(allowed);

        if (allowed) {
            await fetchShares(profile.id);
            setSharedWithRecipient(
                await fetchSharesBetween(currentUserId, profile.id),
            );
            setSharedWithMe(
                await fetchSharesBetween(profile.id, currentUserId),
            );
        }

        setIsLoading(false);
    };

    const updateVisibility = async (visibility: ProfileVisibility) => {
        const { error } = await supabase
            .from("profiles")
            .update({ visibility })
            .eq("id", currentUserId);
        if (error) {
            console.error("Error updating visibility:", error.message);
            return false;
        }
        setProfile((prev) => (prev ? { ...prev, visibility } : prev));
        return true;
    };

    return {
        profile,
        shares,
        sharedWithRecipient,
        sharedWithMe,
        relation,
        canView,
        isLoading,
        error,
        updateVisibility,
    };
}
