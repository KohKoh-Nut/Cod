import { useContext } from "react";
import { DialogContext } from "@/components/ui/DialogProvider";

// Replacement for window.alert/window.confirm -- routes through the app's
// Popup component instead of the browser's native dialog.
export function useDialog() {
    const ctx = useContext(DialogContext);
    if (!ctx) throw new Error("useDialog must be used within DialogProvider");
    return ctx;
}
