import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/utils/supabase-client";
import { ShareHistoryEntry } from "@/hooks/share/useShareCode";

export interface ForkTreeNode {
    id: string;
    user_id: string | null;
    username: string | null;
    language: string | null;
    created_at: string;
    history: ShareHistoryEntry[] | null;
    // false = a locked placeholder standing in for a fork the viewer can't
    // see. Still shown so the branch shape stays visible, but with no details.
    visible: boolean;
    children: ForkTreeNode[];
}

interface TreeRow {
    id: string;
    parent_share_id: string | null;
    user_id: string | null;
    language: string | null;
    created_at: string;
    history: ShareHistoryEntry[] | null;
    visible: boolean;
}

// A node is kept in the tree if it's visible itself, or if any of its
// descendants are. A hidden node with no visible descendants is dropped
// entirely; a hidden node WITH visible descendants is kept as a locked
// placeholder so the branch shape leading to them still shows.
function computeKeptIds(rows: TreeRow[], childrenOf: Map<string, TreeRow[]>) {
    const kept = new Set<string>();
    // A child is always created after its parent, so processing newest-first
    // guarantees every child is resolved before the parent that needs it.
    const newestFirst = [...rows].sort((a, b) =>
        b.created_at.localeCompare(a.created_at),
    );

    for (const row of newestFirst) {
        const hasKeptChild = (childrenOf.get(row.id) ?? []).some((c) =>
            kept.has(c.id),
        );
        if (row.visible || hasKeptChild) kept.add(row.id);
    }
    return kept;
}

function buildTree(
    rootId: string,
    byId: Map<string, TreeRow>,
    childrenOf: Map<string, TreeRow[]>,
    keptIds: Set<string>,
    usernamesById: Map<string, string>,
): ForkTreeNode | null {
    const buildNode = (row: TreeRow): ForkTreeNode | null => {
        if (!keptIds.has(row.id)) return null;
        const children = (childrenOf.get(row.id) ?? [])
            .map(buildNode)
            .filter((n): n is ForkTreeNode => n !== null);
        return {
            id: row.id,
            user_id: row.user_id,
            username: row.user_id
                ? (usernamesById.get(row.user_id) ?? null)
                : null,
            language: row.language,
            created_at: row.created_at,
            history: row.history,
            visible: row.visible,
            children,
        };
    };

    const rootRow = byId.get(rootId);
    return rootRow ? buildNode(rootRow) : null;
}

export function useForkTree(shareId: string | null, isOpen: boolean) {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const [tree, setTree] = useState<ForkTreeNode | null>(null);

    const load = useCallback(async () => {
        if (!shareId) {
            setTree(null);
            return;
        }
        setLoading(true);
        setError("");

        try {
            // Find which tree this share belongs to. This row is always
            // visible to the caller (they're viewing it), so a plain select
            // is fine here -- it's the rest of the tree that needs the
            // security-definer function below.
            const { data: selfRow, error: selfErr } = await supabase
                .from("shares")
                .select("id, root_share_id")
                .eq("id", shareId)
                .single();
            if (selfErr || !selfRow)
                throw selfErr ?? new Error("Share not found");
            const rootId: string = selfRow.root_share_id ?? selfRow.id;

            // Server-side function: computes visibility per row and redacts
            // details for anything the caller can't see, rather than a raw
            // select that RLS would just omit (breaking the tree shape).
            const { data: rows, error: rowsErr } = await supabase.rpc(
                "get_fork_tree_nodes",
                {
                    p_root_id: rootId,
                },
            );
            if (rowsErr) throw rowsErr;

            const allRows = (rows ?? []) as TreeRow[];
            const byId = new Map(allRows.map((r) => [r.id, r]));
            const userIds = [
                ...new Set(
                    allRows
                        .map((r) => r.user_id)
                        .filter((id): id is string => !!id),
                ),
            ];

            const { data: profileRows } = await supabase
                .from("profiles")
                .select("id, username")
                .in(
                    "id",
                    userIds.length
                        ? userIds
                        : ["00000000-0000-0000-0000-000000000000"],
                );
            const usernamesById = new Map(
                (profileRows ?? []).map((p: any) => [p.id, p.username]),
            );

            const childrenOf = new Map<string, TreeRow[]>();
            allRows.forEach((r) => {
                if (!r.parent_share_id) return;
                if (!childrenOf.has(r.parent_share_id))
                    childrenOf.set(r.parent_share_id, []);
                childrenOf.get(r.parent_share_id)!.push(r);
            });

            const keptIds = computeKeptIds(allRows, childrenOf);
            setTree(
                buildTree(rootId, byId, childrenOf, keptIds, usernamesById),
            );
        } catch (err) {
            console.error("Failed to load fork tree:", err);
            setError("Couldn't load fork history.");
            setTree(null);
        } finally {
            setLoading(false);
        }
    }, [shareId]);

    useEffect(() => {
        if (isOpen) load();
    }, [isOpen, load]);

    return { loading, error, tree, reload: load };
}
