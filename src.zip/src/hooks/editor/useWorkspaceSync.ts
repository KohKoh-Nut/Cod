import { useEffect, useState } from "react";
import { supabase } from "@/utils/supabase-client";
import { ShareHistoryEntry } from "@/hooks/share/useShareCode";
import { ShareVisibility } from "@/types/share";

const FORK_STORAGE_KEYS = [
    "forked_code",
    "forked_lang",
    "forked_from_id",
    "forked_history",
    "forked_visibility",
    "forked_recipient_ids",
];

function clearForkStorage() {
    FORK_STORAGE_KEYS.forEach((key) => localStorage.removeItem(key));
}

// Recipient list for a friends-visibility share, via the
// get_share_recipient_ids function -- a raw select on share_recipients
// would only return the caller's own grant row, not co-recipients.
async function fetchRecipientIds(shareId: string) {
    const { data, error } = await supabase.rpc("get_share_recipient_ids", {
        p_share_id: shareId,
    });
    if (error) {
        console.error("Failed to fetch share recipients:", error.message);
        return [];
    }
    return (data ?? []) as string[];
}

// On mount, restores the editor's state from one of two sources:
//   1. a "#/share/:id" URL hash -> loads that share in read-only mode
//   2. a leftover forked_* entry in localStorage -> loads the forked draft
// The hash always wins over localStorage. Without that order, a fork that
// never finished its cleanup step could permanently shadow every future
// share link, since both sources would otherwise be checked in write order.
//
// Access control for friends/private shares is enforced by the `shares`
// RLS policy itself -- if the row comes back empty or errors, that's treated
// as "no access" here rather than silently falling through to a blank editor.
export function useWorkspaceSync(
    setCode: (code: string) => void,
    setLanguage: (language: string) => void,
) {
    const [isInitialLoading, setIsInitialLoading] = useState(true);
    const [isReadOnly, setIsReadOnly] = useState(false);
    const [accessDenied, setAccessDenied] = useState(false);
    const [currentHistory, setCurrentHistory] = useState<ShareHistoryEntry[]>(
        [],
    );

    // currentShareId: the share row currently loaded (read-only view).
    // parentShareId: set when the code came from a fork not yet re-shared,
    // so the next share can record its place in the fork tree.
    const [currentShareId, setCurrentShareId] = useState<string | null>(null);
    const [parentShareId, setParentShareId] = useState<string | null>(null);

    // Seeds for the next share's visibility picker: 'public' for fresh
    // code, or whatever the code being forked from was already set to.
    const [defaultVisibility, setDefaultVisibility] =
        useState<ShareVisibility>("public");
    const [defaultFriendIds, setDefaultFriendIds] = useState<string[]>([]);

    useEffect(() => {
        const loadFromShareHash = async (shareId: string) => {
            const { data, error } = await supabase
                .from("shares")
                .select("*")
                .eq("id", shareId)
                .single();
            if (error || !data) {
                // RLS returning nothing here means either the id doesn't exist,
                // or it does and this viewer isn't allowed to see it -- both
                // read the same from the client, so both show as denied.
                setAccessDenied(true);
                setIsInitialLoading(false);
                return true;
            }

            // Clear any stale fork draft so it can't shadow a future share link
            clearForkStorage();

            // Preselect candidates for the next share's friend picker: whoever
            // shared this with you (the owner) plus any co-recipients. Without
            // the owner here, forking code a friend shared with you would never
            // preselect that friend -- only other people it was also shared with.
            const recipientIds =
                data.visibility === "friends"
                    ? await fetchRecipientIds(data.id)
                    : [];
            const friendCandidates =
                data.visibility === "friends"
                    ? [...new Set([data.user_id, ...recipientIds])]
                    : [];

            setLanguage(data.language);
            // Short delay lets the language change settle before the code does
            setTimeout(() => {
                setCode(data.code);
                setCurrentHistory((data.history as ShareHistoryEntry[]) || []);
                setCurrentShareId(data.id);
                setDefaultVisibility(data.visibility as ShareVisibility);
                setDefaultFriendIds(friendCandidates);
                setIsReadOnly(true);
                setIsInitialLoading(false);
            }, 150);
            return true;
        };

        const loadFromForkedDraft = () => {
            const forkedCode = localStorage.getItem("forked_code");
            const forkedLang = localStorage.getItem("forked_lang");
            if (!forkedCode || !forkedLang) return false;

            const forkedFromId = localStorage.getItem("forked_from_id");
            const forkedHistoryRaw = localStorage.getItem("forked_history");
            const forkedVisibility = localStorage.getItem(
                "forked_visibility",
            ) as ShareVisibility | null;
            const forkedRecipientIdsRaw = localStorage.getItem(
                "forked_recipient_ids",
            );

            setLanguage(forkedLang);
            setTimeout(() => {
                setCode(forkedCode);
                if (forkedHistoryRaw) {
                    try {
                        setCurrentHistory(JSON.parse(forkedHistoryRaw));
                    } catch (err) {
                        console.error("Bad forked history payload:", err);
                    }
                }
                setParentShareId(forkedFromId || null);
                setDefaultVisibility(forkedVisibility ?? "public");
                if (forkedRecipientIdsRaw) {
                    try {
                        setDefaultFriendIds(JSON.parse(forkedRecipientIdsRaw));
                    } catch (err) {
                        console.error("Bad forked recipients payload:", err);
                    }
                }
                clearForkStorage();
                setIsInitialLoading(false);
            }, 100);
            return true;
        };

        const sync = async () => {
            const hash = window.location.hash;
            if (hash.startsWith("#/share/")) {
                const shareId = hash.replace("#/share/", "");
                window.location.hash = "";
                if (shareId && (await loadFromShareHash(shareId))) return;
            }

            if (loadFromForkedDraft()) return;

            setIsInitialLoading(false);
        };

        sync();
    }, [setCode, setLanguage]);

    return {
        isInitialLoading,
        isReadOnly,
        setIsReadOnly,
        accessDenied,
        currentHistory,
        setCurrentHistory,
        currentShareId,
        setCurrentShareId,
        parentShareId,
        setParentShareId,
        defaultVisibility,
        setDefaultVisibility,
        defaultFriendIds,
        setDefaultFriendIds,
    };
}
