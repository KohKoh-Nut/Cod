"use client";
import { useEffect, useRef } from "react";
import * as d3 from "d3";
import { GraphData, GraphNode } from "@/hooks/friends/useFriendGraph";

interface FriendGraphProps {
    data: GraphData;
}

// Force-directed friend graph. Colors are pulled from the theme's CSS
// variables (not hardcoded hex) so this stays correct in both themes.
export default function FriendGraph({ data }: FriendGraphProps) {
    const svgRef = useRef<SVGSVGElement>(null);

    useEffect(() => {
        if (!svgRef.current || data.nodes.length === 0) return;

        const width = svgRef.current.clientWidth;
        const height = svgRef.current.clientHeight;

        d3.select(svgRef.current).selectAll("*").remove();

        const svg = d3
            .select(svgRef.current)
            .attr("viewBox", `0 0 ${width} ${height}`);

        // Arrow marker used at the end of each edge
        svg.append("defs")
            .append("marker")
            .attr("id", "arrow")
            .attr("viewBox", "0 0 10 10")
            .attr("refX", 20)
            .attr("refY", 5)
            .attr("markerWidth", 6)
            .attr("markerHeight", 6)
            .attr("orient", "auto-start-reverse")
            .append("path")
            .attr("d", "M 0 0 L 10 5 L 0 10 z")
            .attr("fill", "var(--color-brand)");

        const simulation = d3
            .forceSimulation(data.nodes as any)
            .force(
                "link",
                d3
                    .forceLink(data.edges)
                    .id((d: any) => d.id)
                    .distance(120),
            )
            .force("charge", d3.forceManyBody().strength(-300))
            .force("center", d3.forceCenter(width / 2, height / 2))
            .force("collision", d3.forceCollide().radius(50));

        const link = svg
            .append("g")
            .selectAll("line")
            .data(data.edges)
            .join("line")
            .attr("stroke", "var(--color-border)")
            .attr("stroke-width", 1.5)
            .attr("marker-end", "url(#arrow)");

        const node = svg
            .append("g")
            .selectAll("g")
            .data(data.nodes)
            .join("g")
            .call(
                d3
                    .drag<SVGGElement, GraphNode>()
                    .on("start", (event, d: any) => {
                        if (!event.active)
                            simulation.alphaTarget(0.3).restart();
                        d.fx = d.x;
                        d.fy = d.y;
                    })
                    .on("drag", (event, d: any) => {
                        d.fx = event.x;
                        d.fy = event.y;
                    })
                    .on("end", (event, d: any) => {
                        if (!event.active) simulation.alphaTarget(0);
                        d.fx = null;
                        d.fy = null;
                    }) as any,
            );

        node.append("circle")
            .attr("r", (d) => (d.isCurrentUser ? 28 : 22))
            .attr("fill", (d) =>
                d.isCurrentUser
                    ? "var(--color-brand)"
                    : "var(--color-bg-element)",
            )
            .attr("stroke", (d) =>
                d.isCurrentUser
                    ? "var(--color-brand-hover)"
                    : "var(--color-border)",
            )
            .attr("stroke-width", 2);

        // Initials on top of the node circle. The current user's node always
        // has a brand-purple fill, so its text stays a fixed white for
        // contrast rather than a themed token.
        node.append("text")
            .text((d) => d.initials)
            .attr("text-anchor", "middle")
            .attr("dominant-baseline", "central")
            .attr("fill", (d) =>
                d.isCurrentUser ? "#ffffff" : "var(--color-fg)",
            )
            .attr("font-size", (d) => (d.isCurrentUser ? "13px" : "11px"))
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-weight", (d) => (d.isCurrentUser ? "700" : "400"));

        node.append("text")
            .text((d) => d.username)
            .attr("text-anchor", "middle")
            .attr("dy", (d) => (d.isCurrentUser ? 40 : 34))
            .attr("fill", "var(--color-comment)")
            .attr("font-size", "10px")
            .attr("font-family", "ui-monospace, monospace");

        simulation.on("tick", () => {
            link.attr("x1", (d: any) => d.source.x)
                .attr("y1", (d: any) => d.source.y)
                .attr("x2", (d: any) => d.target.x)
                .attr("y2", (d: any) => d.target.y);

            node.attr("transform", (d: any) => `translate(${d.x},${d.y})`);
        });

        return () => {
            simulation.stop();
        };
    }, [data]);

    return (
        <svg
            ref={svgRef}
            className="w-full h-full"
            style={{ minHeight: "400px" }}
        />
    );
}
