import { ShareHistoryEntry } from "@/hooks/share/useShareCode";

// Who can open a share's link, chosen once at share time
export type ShareVisibility = "public" | "friends" | "private";

// A single shared code snapshot from the shares table. Both useProfile
// (viewing someone else's profile) and useProfileData (viewing your own)
// return this same shape, so there's one ShareCard for both.
export interface Share {
    id: string;
    code: string;
    language: string;
    created_at: string;
    user_id: string;
    visibility: ShareVisibility;
    history?: ShareHistoryEntry[] | null;
}
