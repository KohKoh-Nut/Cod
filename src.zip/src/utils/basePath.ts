// Mirrors next.config.js's basePath. Next's own router (<Link>,
// useRouter().push) applies basePath automatically, but this app also
// does raw window.location navigation for its hash-based share routes,
// which does not — anything doing that needs this constant.
//
// Source of truth is NEXT_PUBLIC_BASE_PATH in .env.local; keep it in
// sync with next.config.js's basePath value.
export const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || "/Cod";
